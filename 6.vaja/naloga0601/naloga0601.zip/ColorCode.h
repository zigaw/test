#ifndef NALOGA0601_COLORCODE_H
#define NALOGA0601_COLORCODE_H

#include "iostream"
enum class ColorCode {
Red = 31,
Green = 32,
Blue = 34,
Deafult = 39
};


#endif //NALOGA0601_COLORCODE_H
