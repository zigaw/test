#include "StrengthExercise.h"
#ifndef NALOGA1001_PRINTIFSTRENGTHEXERCISE_H
#define NALOGA1001_PRINTIFSTRENGTHEXERCISE_H


class PrintIfStrengthExercise {
public:
    void operator()(Exercise* exercise);

};


#endif //NALOGA1001_PRINTIFSTRENGTHEXERCISE_H
