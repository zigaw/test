#ifndef DIFFICULTY_H
#define DIFFICULTY_H


enum class Difficulty {
    Easy, Normal, Hard
};


#endif // DIFFICULTY_H