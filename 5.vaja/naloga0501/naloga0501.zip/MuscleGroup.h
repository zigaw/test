#ifndef INC_5_VAJA_MUSCLEGORUP_H
#define INC_5_VAJA_MUSCLEGORUP_H


enum class MuscleGroup {
    Legs, Back, Arms
};


#endif //INC_5_VAJA_MUSCLEGORUP_H
